import Vue from "vue";
import Vuex from "vuex";

import moduleBase from "./module";

// Módulos originais do projeto Animalec
import moduleAuth from "./auth/auth.module";
import moduleUser from "./users/user.module";
import moduleAnimal from "./animals/animal.module";
import moduleQuiz from "./quizzes/quiz.module";
import moduleQuestion from "./questions/question.module";

// Módulos adicionados para Tarefa 3.2 e 3.3
import moduleSponsor from "./sponsors/sponsor.module"; // <- Incluído Tarefa 3.2 e 3.3.
import moduleExpert from "./experts/expert.module"; // <- Incluído Tarefa 3.2 e 3.3.

Vue.use(Vuex);

export default new Vuex.Store({
  // Estrutura base do projeto
  getters: moduleBase.getters,
  mutations: moduleBase.mutations,
  state: moduleBase.state,
  actions: moduleBase.actions,

  // Módulos Vuex registados
  modules: {
    auth: moduleAuth,
    user: moduleUser,
    animal: moduleAnimal,
    question: moduleQuestion,
    quiz: moduleQuiz,

    // Novos módulos
    sponsor: moduleSponsor, // <- Sponsors
    expert: moduleExpert // <- Experts
  }
});
