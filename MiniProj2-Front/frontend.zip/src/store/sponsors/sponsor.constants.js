// Ficheiro adicionado para Tarefa 3.2 e 3.3.
// Constantes usadas pelo módulo Vuex de Sponsors.

export const FETCH_SPONSORS = "fetchSponsors";
export const ADD_SPONSOR = "addSponsor";
export const EDIT_SPONSOR = "editSponsor";
export const REMOVE_SPONSOR = "removeSponsor";

export const SET_SPONSORS = "setSponsors";
export const SET_MESSAGE = "setMessage";
