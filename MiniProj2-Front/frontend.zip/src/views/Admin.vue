<template>
  <section class="page-section">
    <b-container fluid>
      <HeaderPage title="Gestão do Animalec" />

      <b-row>
        <b-col cols="4"></b-col>

        <b-col cols="4">
          <!-- 1ª LINHA - Módulos originais -->
          <b-card-group deck>
            <AdminOptionBox
              routeName="listUsers"
              iconName="users"
              title="Utilizadores"
            />
            <AdminOptionBox
              routeName="listAnimals"
              iconName="dog"
              title="Animais"
            />
          </b-card-group>

          <!-- 2ª LINHA - Módulos originais -->
          <b-card-group deck class="mt-3">
            <AdminOptionBox
              routeName="listQuizzes"
              iconName="file-alt"
              title="Quizzes"
            />
            <AdminOptionBox
              routeName="listQuestions"
              iconName="question-circle"
              title="Questões"
            />
          </b-card-group>

          <!-- 3ª LINHA - NOVOS MÓDULOS (Tarefa 3.2 e 3.3) -->
          <b-card-group deck class="mt-3">
            <!-- Patrocinadores -->
            <AdminOptionBox
              routeName="listSponsors"
              iconName="handshake"
              title="Patrocinadores"
            />

            <!-- Especialistas -->
            <AdminOptionBox
              routeName="listExperts"
              iconName="user-tie"
              title="Especialistas"
            />
          </b-card-group>
        </b-col>

        <b-col cols="4"></b-col>
      </b-row>
    </b-container>
  </section>
</template>

<script>
import HeaderPage from "@/components/HeaderPage.vue";
import AdminOptionBox from "@/components/AdminOptionBox.vue";

export default {
  components: {
    HeaderPage,
    AdminOptionBox
  }
};
</script>
