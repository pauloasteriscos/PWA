# Animalec
An animals pedagogical app

# Using json-server 
To mock some dummy results
https://github.com/typicode/json-server
